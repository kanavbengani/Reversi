package cs3500.reversi.strategy;

public interface ReversiStrategy {
  
}
